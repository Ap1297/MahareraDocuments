package com.pwc.dms.utils;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LDAPUtil {
	Properties properties;
	DirContext dirContext;
	SearchControls searchCtls;
	private String[] returnAttributes = { "sAMAccountName", "givenName", "cn", "mail" };
    private String domainBase;
    private String baseFilter = "(&((&(objectCategory=Person)(objectClass=User)))";
	public LDAPUtil(String userName, String pass, String domainCtrl) {
		properties = new Properties();
	    properties.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
	    properties.put(Context.PROVIDER_URL, "LDAP://" + domainCtrl);
	    properties.put(Context.SECURITY_AUTHENTICATION, "simple");
	    properties.put(Context.SECURITY_PRINCIPAL, "cn=test");
	    properties.put(Context.SECURITY_CREDENTIALS, pass);
	 
	    // initializing active directory LDAP connection
	    try {
	        dirContext = new InitialDirContext(properties);
	    } catch (NamingException e) {
	        e.printStackTrace();
	    }    
	 
	    // default domain base for search
	    domainBase = getDomainBase(domainCtrl);    
	 
	    // initializing search controls
	    searchCtls = new SearchControls();
	    searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	    searchCtls.setReturningAttributes(returnAttributes);
	}

	public NamingEnumeration<SearchResult> searchUser(String searchValue, String searchBy, String searchBase)
			throws NamingException {
		String filter = getFilter(searchValue, searchBy);
		String base = (null == searchBase) ? domainBase : getDomainBase(searchBase);
		return this.dirContext.search(base, filter, this.searchCtls);
	}
	
	private String getFilter(String searchValue, String searchBy) {
		String filter = this.baseFilter;
		if (searchBy.equals("email")) {
			filter += "(mail=" + searchValue + "))";
		} else if (searchBy.equals("username")) {
			filter += "(samaccountname=" + searchValue + "))";
		}
		return filter;
	}
	
	private static String getDomainBase(String base) {
		char[] namePair = base.toUpperCase().toCharArray();
		String dn = "DC=";
		for (int i = 0; i < namePair.length; i++) {
			if (namePair[i] == '.') {
				dn += ",DC=" + namePair[++i];
			} else {
				dn += namePair[i];
			}
		}
		return dn;
	}
	
	public void closeLdapConnection(){
		try {
			if (dirContext != null)
				dirContext.close();
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	
}
