package com.pwc.dms.enums;



public enum NODE_TYPE {
	FOLDER("cm:folder"),
	FILE("cm:content");
	
	private String name;
	NODE_TYPE(String name) {
        this.name = name;
    }

	public String getName() {
		return name;
	}
}
