package com.pwc.dms.model;

import java.util.List;

public class NewFileUploadResponse {
	
	private List<String> fileUploadResponse;
	private String errorMessage;

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<String> getFileUploadResponse() {
		return fileUploadResponse;
	}

	public void setFileUploadResponse(List<String> fileUploadResponse) {
		this.fileUploadResponse = fileUploadResponse;
	}

}
