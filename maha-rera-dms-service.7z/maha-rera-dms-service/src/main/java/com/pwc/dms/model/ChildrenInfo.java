package com.pwc.dms.model;

import java.util.Date;

public class ChildrenInfo {
	private String name;
	private String description;
	private String createdBy;
	private String createdOn;
	private String type;
	private String modifiedBy;
	private String modifiedOn;
	private String id;
	private String docType;
	private String category;
	private String issuer;
	private String[] tag;
	private Date publishDate;
	private Date validity;
	private Date refDateNew;
	private String docNo;
	private boolean isExpired;
	private String metadata;
	private String docId;
	private String subject;
	private String department;
	private boolean editable;
	private String url;
	private boolean versioned;
	
	
	public Date getRefDateNew() {
		return refDateNew;
	}
	public void setRefDateNew(Date refDateNew) {
		this.refDateNew = refDateNew;
	}
	public boolean isVersioned() {
		return versioned;
	}
	public void setVersioned(boolean versioned) {
		this.versioned = versioned;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public boolean isEditable() {
		return editable;
	}
	public void setEditable(boolean editable) {
		this.editable = editable;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getMetadata() {
		return metadata;
	}
	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}
	public boolean isExpired() {
		return isExpired;
	}
	public void setExpired(boolean isExpired) {
		this.isExpired = isExpired;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getDocType() {
		return docType;
	}
	public String getCategory() {
		return category;
	}
	public String getIssuer() {
		return issuer;
	}
	public String[] getTag() {
		return tag;
	}
	public Date getPublishDate() {
		return publishDate;
	}
	public Date getValidity() {
		return validity;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}
	public void setTag(String[] tag) {
		this.tag = tag;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	public void setValidity(Date validity) {
		this.validity = validity;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public String getType() {
		return type;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

}
