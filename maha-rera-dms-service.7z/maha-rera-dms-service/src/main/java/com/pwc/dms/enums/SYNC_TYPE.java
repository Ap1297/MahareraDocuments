package com.pwc.dms.enums;

public enum SYNC_TYPE {
	
}
