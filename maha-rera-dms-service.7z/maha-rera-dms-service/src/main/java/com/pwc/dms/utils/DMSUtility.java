package com.pwc.dms.utils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.apache.commons.httpclient.Header;
import org.apache.http.message.BasicHeader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.pwc.dms.enums.NODE_TYPE;
import com.pwc.dms.enums.SYNC_TYPE;
import com.pwc.dms.model.CreateNodeReq;


public enum DMSUtility {
	INSTANCE;
	
	
	private String remoteDmsUrl;
	private String alfBaseUrlLocal;
	private String alfBaseUrlRemote;
	private String alfPass;
	private String remotePass;
	private String docLibRootId;
	
	
	public String getDocLibRootId() {
		return docLibRootId;
	}
	public void setDocLibRootId(String docLibRootId) {
		this.docLibRootId = docLibRootId;
	}
	public String getAlfBaseUrlLocal() {
		return alfBaseUrlLocal;
	}
	public String getAlfBaseUrlRemote() {
		return alfBaseUrlRemote;
	}
	public void setAlfBaseUrlLocal(String alfBaseUrlLocal) {
		this.alfBaseUrlLocal = alfBaseUrlLocal;
	}
	public void setAlfBaseUrlRemote(String alfBaseUrlRemote) {
		this.alfBaseUrlRemote = alfBaseUrlRemote;
	}
	public String getRemoteDmsUrl() {
		return remoteDmsUrl;
	}
	public void setRemoteDmsUrl(String remoteDmsUrl) {
		this.remoteDmsUrl = remoteDmsUrl;
	}
	
	
	public CreateNodeReq populateFolderRequest(String folderName) {
		CreateNodeReq req = new CreateNodeReq();
		req.setName(folderName);
		req.setNodeType(NODE_TYPE.FOLDER.getName());
		
		return req;
	}
	public Header getHeader() {
		Header hd = new Header();
		hd.setName("Authorization");
		hd.setValue(this.alfPass);
		return hd;
	}
	
	public org.apache.http.Header getBasicHeader() {
		org.apache.http.Header hd = new BasicHeader("Authorization", "Basic "+this.alfPass);
		return hd;
	}
	
	public void setAlfPass(String base64Pass) {
		this.alfPass = base64Pass;
	}
	
	
	public Session getSession(String url, String user, String pass) throws Exception{
		SessionFactory factory = null;
		Map<String, String> params = null;
		try {
			System.out.println("get session");
			params = new HashMap<>();
			factory = SessionFactoryImpl.newInstance();
			params.put(SessionParameter.ATOMPUB_URL, url +"/alfresco/api/-default-/public/cmis/versions/1.1/atom");
			params.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value());
			params.put(SessionParameter.AUTH_HTTP_BASIC, "true");
			params.put(SessionParameter.USER, user);
			params.put(SessionParameter.PASSWORD, pass);
			System.out.println("connecting dms repository");
			List<Repository> repos = factory.getRepositories(params);
			
			if(repos == null || repos.size()==0)
				throw new Exception("No repository found");
			System.out.println("repo size "+repos.size());
			return repos.get(0).createSession();
		} catch(Exception e) {
			throw new Exception("Can't get session "+e.getMessage());
		}
	}
	
	public String getStrDate(GregorianCalendar cal) {
		Date date = cal.getTime();
		SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		return sf.format(date);
	}
	
	public String[] getUserPass(Header header) {
		String head = header.getValue();
		String base64Pass = head.split(" ")[1];
		byte[] plainTxtByte = Base64.getDecoder().decode(base64Pass);
		String plainTxt = new String(plainTxtByte);
		return  plainTxt.split(":");
	}
	
	public String getAlfTicket(String alfurl, String user, String pass) throws Exception {
		String _ticket = "";

		URL url;
		HttpURLConnection connection = null;
		try {
			String urlParameters = "{ \"username\" : \"" + user + "\", \"password\" : \""
					+ pass + "\" }";

			url = new URL(alfurl+"/alfresco/service/api/login");
			connection = (HttpURLConnection) url.openConnection();

			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
			connection.setRequestProperty("Content-Language", "en-US");
			connection.setUseCaches(false);
			connection.setDoInput(true);
			connection.setDoOutput(true);

			DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();

			InputStream is = connection.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			String line;
			StringBuffer response = new StringBuffer();
			while ((line = rd.readLine()) != null) {
				response.append(line);
				response.append('\r');
			}
			rd.close();
			String _jsonResponse = response.toString();

			JSONObject _jsonResponseObject = (JSONObject) new JSONParser().parse(_jsonResponse);
			JSONObject jsonDataObject = (JSONObject) new JSONParser().parse(_jsonResponseObject.get("data").toString());
			_ticket = jsonDataObject.get("ticket").toString();
			return _ticket;
		} catch (Exception e) {
			throw new Exception("Error while getting alf ticket. "+e.getMessage());
		}
	}

	public void setRemotePass(String pass) {
		this.remotePass = pass;
	}

	public String[] getRemotePass() {
		String base64Pass = this.remotePass;
		base64Pass = base64Pass.split(" ")[1];
		byte[] plainTxtByte = Base64.getDecoder().decode(base64Pass);
		String plainTxt = new String(plainTxtByte);
		return  plainTxt.split(":");
	}
	
	private boolean inProgress;

	public boolean isInProgress() {
		return inProgress;
	}

	public void setInProgress(boolean inProgress) {
		this.inProgress = inProgress;
	}
	
}
