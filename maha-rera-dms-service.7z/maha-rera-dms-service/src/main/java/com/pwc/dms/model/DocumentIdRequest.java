package com.pwc.dms.model;

public class DocumentIdRequest {
	
	private String documentId;

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

}
