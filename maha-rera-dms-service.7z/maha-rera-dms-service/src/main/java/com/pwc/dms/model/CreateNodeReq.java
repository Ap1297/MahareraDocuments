package com.pwc.dms.model;

import java.util.List;



public class CreateNodeReq {
	private String name;
	private String nodeType;
	private String id;
	private String binaryContent;
	private String remoteId;
	private List<String> aspectNames;
	private NodePoperties properties;
	private List<Tag> tag;
	private String appName;
	private String user;
	
	
	public String getAppName() {
		return appName;
	}
	public String getUser() {
		return user;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public List<Tag> getTag() {
		return tag;
	}
	public void setTag(List<Tag> tag) {
		this.tag = tag;
	}
	public List<String> getAspectNames() {
		return aspectNames;
	}
	public NodePoperties getProperties() {
		return properties;
	}
	public void setAspectNames(List<String> aspectNames) {
		this.aspectNames = aspectNames;
	}
	public void setProperties(NodePoperties properties) {
		this.properties = properties;
	}
	public String getName() {
		return name;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBinaryContent() {
		return binaryContent;
	}
	public void setBinaryContent(String binaryContent) {
		this.binaryContent = binaryContent;
	}
	public String getRemoteId() {
		return remoteId;
	}
	public void setRemoteId(String remoteId) {
		this.remoteId = remoteId;
	}
	
}
