package com.pwc.dms.model;

public class UpdateVersionResponse extends ServiceResponseStatics{
	
	private String docId;

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

}
