package com.pwc.dms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.scheduling.annotation.EnableScheduling;

import brave.sampler.Sampler;


@ServletComponentScan
@Configuration
//@EnableAutoConfiguration
@ComponentScan
@SpringBootApplication
//@EnableDiscoveryClient
@EnableEurekaClient
public class DmsApplication extends SpringBootServletInitializer {
	
	public static void main(String[] args) {
		SpringApplication.run(DmsApplication.class, args);
	}
	
	@Bean 
	public Sampler defaultSampler() { 
	  return Sampler.ALWAYS_SAMPLE; 
	}

}
