package com.pwc.dms.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.FileableCmisObject;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.chemistry.opencmis.client.api.ObjectId;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.api.Tree;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.BaseTypeId;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisConnectionException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisContentAlreadyExistsException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.pwc.dms.model.ChildrenInfo;
import com.pwc.dms.model.DocumentDownloadRequest;
import com.pwc.dms.model.DocumentDownloadRequestNew;
import com.pwc.dms.model.DocumentIdRequest;
import com.pwc.dms.model.FolderTreeModel;
import com.pwc.dms.model.RmsUploadRequest;
import com.pwc.dms.model.ServiceResponseStatics;
import com.pwc.dms.model.UpdateVersionResponse;
import com.pwc.dms.utils.DMSUtility;

@Service
public class NodeService {
	private static final Logger logger = LoggerFactory.getLogger(NodeService.class);

	@Bean
	public RestTemplate template() {
		return new RestTemplate();
	}

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private Environment env;

	@Value("${tempDirectory}")
	String tempDirectoryPath;

	@Value("${alfresco_local_base_url}")
	String alfrescoUrl;
	@Value("${alfrescoUser}")
	String alfrescoUser;
	@Value("${alfrescoPassword}")
	String alfrescoPassword;

	@Value("${sharedDirectoryName}")
	String directoryName;

	public List<FolderTreeModel> getAllFolderNodes(String nodeId) throws Exception {
		final String methodName = "getAllFolderNodes";
		logger.debug("Entered into method :: " + methodName);
		Header header = DMSUtility.INSTANCE.getHeader();
		String head = header.getValue();
		String base64Pass = head.split(" ")[1];
		byte[] plainTxtByte = Base64.getDecoder().decode(base64Pass);
		String plainTxt = new String(plainTxtByte);
		String user = plainTxt.split(":")[0];
		String pass = plainTxt.split(":")[1];
		Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), user, pass);
		if (curSession == null)
			throw new Exception("Unauthorized access");
		Folder docLibRoot = (Folder) curSession.getObject(nodeId);

		List<Tree<FileableCmisObject>> trees = docLibRoot.getFolderTree(1);
		List<FolderTreeModel> list = new ArrayList<>();
		FolderTreeModel model = null;
		List<FolderTreeModel> emptyList = new ArrayList<>();
		for (Tree<FileableCmisObject> item : trees) {
			model = new FolderTreeModel();
			model.setLabel(item.getItem().getName());
			model.setKey(item.getItem().getId());
			list.add(model);
		}
		logger.debug("Exited from method :: " + methodName);
		return list;
	}

	public String createContent(RmsUploadRequest req, MultipartFile file) throws Exception {

		Document doc = null;
		final String methodName = "createContent";
		logger.debug("Entered into method :: " + methodName);
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		// logger.debug("User pass :: "+arr[0]+":"+arr[1]);
		String url = DMSUtility.INSTANCE.getAlfBaseUrlLocal();
		// logger.debug("=======>"+url);
		Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0], arr[1]);
		// m(curSession);
		System.out.println("=====>" + curSession.getRootFolder().getName());
		Iterator<CmisObject> it = curSession.getRootFolder().getChildren().iterator();

		while (it.hasNext()) {
			CmisObject object = it.next();
			System.out.println(object.getName());
			if (object.getName().equals("shared")) {
				String id = object.getId();
			}

		}
		// Folder subFolder = createFolder

		//
		//////////////////////////////////////////////////
		// Folder parentFolder = getParentFolder(curSession);
		// folder = createFolder(cmisSession, parentFolder, FOLDER_NAME);
		//////////////////////////////////////////////////
		// System.out.println ("====>"+file.getContentType());
		/*
		 * if(!file.isEmpty()) { Tika tika = new Tika(); String detectedType =
		 * tika.detect(file.getBytes()); System.out.println(detectedType); }
		 */

		if (curSession == null)
			throw new Exception("Unauthorized access");

		int extId = file.getOriginalFilename().lastIndexOf(".");

		String ext = file.getOriginalFilename().substring(extId);
		// String fileNameWithOutExt =
		// file.getOriginalFilename().replaceFirst("[.][^.]+$", "");
		// req.setTitle(fileNameWithOutExt);
		String title = req.getTitle();

		req.setTitle(title + "-" + String.valueOf(System.currentTimeMillis()));
		String completeFileName = req.getTitle() + ext;
		Map<String, Object> properties = getContentProperties(req, ext);
		int i = 0;

		for (String path : req.getPath()) {
			Folder parent = getParentNode(path, curSession);
			ContentStream cs = curSession.getObjectFactory().createContentStream(completeFileName, file.getSize(),
					file.getContentType(), file.getInputStream());

			try {
				doc = parent.createDocument(properties, cs, VersioningState.MINOR);
				// System.out.println("docId=====>"+doc.getId());
			} catch (Exception e) {
				SimpleDateFormat ss = new SimpleDateFormat("mmss");
				req.setTitle(req.getTitle() + "-" + ss.format(new Date()));
				properties.put(PropertyIds.NAME, req.getTitle() + ext);
				doc = parent.createDocument(properties, cs, VersioningState.MINOR);
			}

			if (doc != null)
				// saveMetadata(doc.getId(), req, doc.getName(), req.getRegion().get(i), null,
				// req.getUserGroup(), path);
				i++;
		}

		logger.debug("Exited from method :: " + methodName);
		return doc.getId();
	}

	public UpdateVersionResponse createContentWithVersion(RmsUploadRequest req, MultipartFile file, String docId) {
		logger.debug("Entered into method :: " + "createContentWithVersion");
		UpdateVersionResponse updateVesionResponse = new UpdateVersionResponse();
		final String methodName = "createContent";
		logger.debug("Entered into method :: " + methodName);
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		// logger.debug("User pass :: "+arr[0]+":"+arr[1]);
		Document doc = null;

		try {
			Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0],
					arr[1]);
			if (curSession == null)
				throw new Exception("Unauthorized access");
			doc = (Document) curSession.getObject(docId);

			int extId = file.getOriginalFilename().lastIndexOf(".");

			String ext = file.getOriginalFilename().substring(extId);
			// String fileNameWithOutExt =
			// file.getOriginalFilename().replaceFirst("[.][^.]+$", "");
			// req.setTitle(fileNameWithOutExt);
			String title = req.getTitle();

			req.setTitle(title + "-" + String.valueOf(System.currentTimeMillis()));
			String completeFileName = req.getTitle() + ext;
			Map<String, Object> properties = getContentProperties(req, ext);
			int i = 0;

			Folder parent = getParentNode(directoryName, curSession);
			ContentStream contentStream = null;
			// ContentStream cs =
			// curSession.getObjectFactory().createContentStream(completeFileName,
			// file.getSize(), file.getContentType(), file.getInputStream());

			// Document doc = null;

			// doc = parent.createDocument(properties, cs, VersioningState.MINOR);
			// Now update it with a new version
			if (doc.getAllowableActions().getAllowableActions()
					.contains(org.apache.chemistry.opencmis.commons.enums.Action.CAN_CHECK_OUT)) {
				doc.refresh();
				String testName = doc.getContentStream().getFileName();
				ObjectId idOfCheckedOutDocument = doc.checkOut();
				Document pwc = (Document) curSession.getObject(idOfCheckedOutDocument);
				// docText = "This is a sample document with an UPDATE";
				// content = docText.getBytes();
				// stream = new ByteArrayInputStream(content);
				contentStream = curSession.getObjectFactory().createContentStream(completeFileName, file.getSize(),
						file.getContentType(), file.getInputStream());
				ObjectId objectId = pwc.checkIn(false, null, contentStream, "just a minor change");

				doc = (Document) curSession.getObject(objectId);
				// System.out.println("Version label is now:" + doc.getVersionLabel());
				// System.out.println("Doc id at new version" + doc.getId());
				for (Document version : doc.getAllVersions()) {
					// System.out.println(version.getVersionLabel());
				}
				Document latest = null;
				if (Boolean.TRUE.equals(doc.isLatestVersion())) {
					latest = doc;
					// System.out.println("latest version "+latest.getId());
					updateVesionResponse.setDocId(latest.getId());
				} else {
					latest = doc.getObjectOfLatestVersion(false); // major = false
					// System.out.println("latest version === >"+latest.getId());
					updateVesionResponse.setDocId(latest.getId());

				}
			}
			updateVesionResponse.setMessage("success");
			updateVesionResponse.setStatus("0");

		} catch (Exception e) {
			logger.debug("Exited from method with error:: " + "createContentWithVersion");
			updateVesionResponse.setMessage("failure");
			updateVesionResponse.setStatus("1");
			e.printStackTrace();

		}

		if (doc != null)
			// saveMetadata(doc.getId(), req, doc.getName(), req.getRegion().get(i), null,
			// req.getUserGroup(), path);

			logger.debug("Exited from method :: " + "createContentWithVersion");
		return updateVesionResponse;
	}

	public HashMap<String, String> createBulkContent(RmsUploadRequest req, File file) throws Exception {
		final String methodName = "createContent";
		logger.debug("Exited from method :: " + methodName);
		HashMap<String, String> fileMap = new HashMap<String, String>();
		logger.debug("Entered into method :: " + methodName);
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		// logger.debug("User pass :: "+arr[0]+":"+arr[1]);
		Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0], arr[1]);
		if (curSession == null)
			throw new Exception("Unauthorized access");

		int extId = file.getName().lastIndexOf(".");

		String ext = file.getName().substring(extId);
		String docName = file.getName() + String.valueOf(System.currentTimeMillis()) + ext;
		req.setTitle(docName);

		Map<String, Object> properties = getContentProperties(req, ext);
		int i = 0;
		for (String path : req.getPath()) {
			Folder parent = getParentNode(path, curSession);
			// ContentStream cs =
			// curSession.getObjectFactory().createContentStream(req.getTitle()+ext,
			// file.length(), Files.probeContentType(Paths.get(file.getAbsolutePath())), new
			// FileInputStream(file));
			ContentStream cs = curSession.getObjectFactory().createContentStream(docName, file.length(),
					Files.probeContentType(Paths.get(file.getAbsolutePath())), new FileInputStream(file));
			Document doc = null;
			try {
				doc = parent.createDocument(properties, cs, VersioningState.MINOR);
				fileMap.put(path, doc.getId());
				// System.out.println("===>"+doc.getId());

			} catch (Exception e) {
				e.printStackTrace();
				SimpleDateFormat ss = new SimpleDateFormat("mmss");
				req.setTitle(req.getTitle() + "-" + ss.format(new Date()) + ((int) Math.random() * 100000));
				properties.put(PropertyIds.NAME, req.getTitle() + ext);
				doc = parent.createDocument(properties, cs, VersioningState.MINOR);
				fileMap.put(path, doc.getId());
				// System.out.println("===>"+doc.getId());
			} finally {

			}

			if (doc != null)
				// saveMetadata(doc.getId(), req, doc.getName(), req.getRegion().get(i), null,
				// req.getUserGroup(), path);
				i++;
		}
		logger.debug("Exited from method :: " + methodName);
		return fileMap;
	}

	public Folder getParentNode(String path, Session curSession) {
		final String methodName = "getParentNode";
		logger.debug("Entered into method :: " + methodName);
		Folder root = (Folder) curSession.getObject(getSharedRootFolder("-shared-"));
		String pathArr[] = path.split("/");
		for (int i = 0; i < pathArr.length; i++) {
			List<Tree<FileableCmisObject>> children = root.getFolderTree(1);
			Folder temp = doesFolderExists(children, pathArr[i]);
			if (temp == null) {
				Map<String, Object> props = new HashMap<>();
				props.put(PropertyIds.OBJECT_TYPE_ID, BaseTypeId.CMIS_FOLDER.value());
				props.put(PropertyIds.NAME, pathArr[i]);
				root = root.createFolder(props, null, null, null, curSession.getDefaultContext());
			} else {
				root = temp;
			}
		}
		logger.debug("Exited from method :: " + methodName);
		return root;
	}

	private String getSharedRootFolder(String nodeId) {
		HttpClient client;
		GetMethod docsGet;
		JSONParser parser;
		JSONObject obj;
		String id = null;
		try {
			client = new HttpClient();
			docsGet = new GetMethod(DMSUtility.INSTANCE.getAlfBaseUrlLocal()
					+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId);
			docsGet.setRequestHeader(DMSUtility.INSTANCE.getHeader());
			int status = client.executeMethod(docsGet);
			if (status == 200) {
				String resp = docsGet.getResponseBodyAsString();
				parser = new JSONParser();
				obj = (JSONObject) parser.parse(resp);
				obj = (JSONObject) obj.get("entry");
				id = (String) obj.get("id");
			}
		} catch (Exception e) {

		}
		return id;
	}

	private Folder doesFolderExists(List<Tree<FileableCmisObject>> children, String folderName) {
		final String methodName = "doesFolderExists";
		logger.debug("Entered into method :: " + methodName);
		if (children == null || children.size() == 0)
			return null;
		for (Tree<FileableCmisObject> obj : children) {
			FileableCmisObject item = obj.getItem();
			if (item.getType().getBaseTypeId() == BaseTypeId.CMIS_FOLDER && item.getName().equals(folderName)) {
				logger.debug("Exited from method :: " + methodName);
				return (Folder) item;
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public void addTag(String id, Set<String> tags) throws Exception {
		final String methodName = "addTag";
		logger.debug("Entered into method :: " + methodName);
		HttpClient client = new HttpClient();
		PostMethod createTag = new PostMethod(DMSUtility.INSTANCE.getAlfBaseUrlLocal()
				+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + id + "/tags");

		List<JSONObject> object = new ArrayList<>();
		JSONObject obj;
		for (String tag : tags) {
			obj = new JSONObject();
			obj.put("tag", tag);
			object.add(obj);
		}

		createTag.setRequestHeader("Content-Type", "application/json");
		createTag.setRequestHeader("Accept", "application/json");
		createTag.setRequestHeader(DMSUtility.INSTANCE.getHeader());
		createTag.setRequestEntity(new StringRequestEntity(object.toString(), "application/json", "UTF-8"));
		client.executeMethod(createTag);
		logger.debug("Exited from method :: " + methodName);
	}

	private Map<String, Object> getContentProperties(RmsUploadRequest req, String ext) {
		final String methodName = "getContentProperties";
		logger.debug("Entered into method :: " + methodName);
		Map<String, Object> props = new HashMap<>();
		props.put(PropertyIds.NAME, req.getTitle() + ext);
		props.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
		if (req.getCreatedBy() == null || req.getCreatedBy().length() == 0)
			props.put(PropertyIds.CREATED_BY, req.getModifiedBy());
		else
			props.put(PropertyIds.CREATED_BY, req.getCreatedBy());
		props.put(PropertyIds.CREATION_DATE, Calendar.getInstance());
		props.put(PropertyIds.DESCRIPTION, req.getSubject());
		logger.debug("Exited from method :: " + methodName);
		return props;
	}

	public void createFolder(ChildrenInfo bean, String id) throws Exception {
		final String methodName = "createFolder";
		logger.debug("Entered into method :: " + methodName);
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0], arr[1]);
		Folder docLibRoot = (Folder) curSession.getObject(id);
		Map<String, ?> properties = getFolderProperties(bean);
		docLibRoot.createFolder(properties);
		logger.debug("Exited from method :: " + methodName);
	}

	private Map<String, ?> getFolderProperties(ChildrenInfo bean) {
		final String methodName = "getFolderProperties";
		logger.debug("Entered into method :: " + methodName);
		Map<String, Object> props = new HashMap<>();
		props.put(PropertyIds.NAME, bean.getName());
		props.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
		props.put(PropertyIds.CREATED_BY, bean.getCreatedBy());
		props.put(PropertyIds.CREATION_DATE, Calendar.getInstance());
		props.put(PropertyIds.DESCRIPTION, bean.getDescription());
		logger.debug("Exited from method :: " + methodName);
		return props;
	}

	public Document getFileObject(String id) throws Exception {
		final String methodName = "getFileObject";
		logger.debug("Entered into method :: " + methodName);
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0], arr[1]);
		if (curSession == null)
			throw new Exception("Unauthorized access");
		Document obj = (Document) curSession.getObject(id);
		logger.debug("Exited from method :: " + methodName);
		return obj;
	}

	public String getZippedFile(String id) throws Exception {
		final String methodName = "getZippedFile";
		logger.debug("Entered into method :: " + methodName);
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0], arr[1]);
		if (curSession == null)
			throw new Exception("Unauthorized access");
		Folder folder = (Folder) curSession.getObject(id);
		String path = createZipFile(folder);
		logger.debug("Exited from method :: " + methodName);
		return path;
	}

	private String createZipFile(Folder folder) throws Exception {
		final String methodName = "createZipFile";
		logger.debug("Entered into method :: " + methodName);
		ItemIterable<CmisObject> objs = folder.getChildren();
		if (objs == null)
			return null;
		Iterator<CmisObject> it = objs.iterator();
		if (it == null)
			return null;
		String dt = new SimpleDateFormat("ddMMyyyyHHmmss").format(new Date());
		String zipPath = folder.getName() + dt + ".zip";
		FileOutputStream fo = new FileOutputStream(zipPath);
		ZipOutputStream zo = new ZipOutputStream(fo);
		byte[] buffer = new byte[1024];
		int count = 0;
		while (it.hasNext()) {
			CmisObject item = it.next();
			if (item.getType().getBaseTypeId() == BaseTypeId.CMIS_DOCUMENT) {
				Document doc = (Document) item;
				InputStream is = doc.getContentStream().getStream();
				zo.putNextEntry(new ZipEntry(doc.getName()));
				int length;
				while ((length = is.read(buffer)) > 0) {
					zo.write(buffer, 0, length);
				}
				zo.closeEntry();
				is.close();
				count++;
			}
		}
		zo.close();
		logger.debug("Exited from method :: " + methodName);
		if (count == 0)
			return null;
		return zipPath;
	}

	public void downloadDocumentByID(String serverUrl, String username, String password, String documentID,
			String fileName, String destinationFolder) {
		String fullPath = destinationFolder + fileName;
		Session session = getSession(serverUrl, username, password);
		Document newDocument = (Document) session.getObject(documentID);
		// System.out.println(newDocument.getId());
		try {
			ContentStream cs = newDocument.getContentStream(null);
			BufferedInputStream in = new BufferedInputStream(cs.getStream());
			FileOutputStream fos = new FileOutputStream(fullPath);
			OutputStream bufferedOutputStream = new BufferedOutputStream(fos);
			byte[] buf = new byte[1024];
			int n = 0;
			while ((n = in.read(buf)) > 0) {
				bufferedOutputStream.write(buf, 0, n);
			}
			bufferedOutputStream.close();
			fos.close();
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getLocalizedMessage());
		} finally {
			if (session != null) {

				session.clear();
			}
			session = null;
		}
	}

	public byte[] bulkDownload(DocumentDownloadRequest request) {
		logger.debug("Entered method " + "bulkDownload");
		ServiceResponseStatics errorResponse = new ServiceResponseStatics();
		ByteArrayOutputStream baos = null;
		final String methodName = "downloadRmsObject";
		List<String> fileNameList = new ArrayList<String>();
		String originalFileName = null;
		List<File> fileList = new ArrayList<File>();
		Session session = null;
		try {

			session = this.getSession("filedownloadConnection", "", "");
		} catch (Exception ex) {
			errorResponse.setMessage("can not fetch session from repo");
			errorResponse.setStatus("1");
			Gson json = new Gson();
			String error = json.toJson(errorResponse);
			return error.getBytes();
		}
		for (String docId : request.getDocIds()) {
			try {
				final Document newDocument = (Document) session.getObject(docId);
				// System.out.println("ContentType===================>" +
				// newDocument.getContentStreamMimeType());
				// System.out.println("ContentLength===================>" +
				// newDocument.getContentStreamLength());
				// System.out.println(newDocument.getId());
				// System.out.println(newDocument.getContentStreamFileName());
				fileNameList.add(newDocument.getContentStreamFileName());
				final ContentStream cs = newDocument.getContentStream(null);
				final InputStream is = cs.getStream();
				String name = newDocument.getContentStreamFileName();
				String path = tempDirectoryPath + name;
				File f = new File(path);
				fileList.add(f);

				try {
					// Files.copy(is, path, StandardCopyOption.REPLACE_EXISTING);
					FileUtils.copyInputStreamToFile(is, f);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// fileName = newDocument.getContentStreamFileName();
			} catch (Exception ex) {
				errorResponse.setMessage("failure object not found");
				errorResponse.setStatus("1");
				Gson json = new Gson();
				String error = json.toJson(errorResponse);
				return error.getBytes();

			}
		}
		final InputStreamReader isr = null;
		HttpHeaders headers = null;
		InputStreamResource resource = null;
		ZipOutputStream zos = null;

		String fileName = null;
		byte[] zipFile = null;

		try {

			/////////////////////////////////////
			baos = new ByteArrayOutputStream();
			zos = new ZipOutputStream(baos);
			for (String fileNameFromList : fileNameList) {
				ZipEntry entry = new ZipEntry(fileNameFromList);
				zos.putNextEntry(entry);
				zos.write(Files.readAllBytes(Paths.get(tempDirectoryPath + fileNameFromList)));
			}
			for (File fileObj : fileList) {
				fileObj.delete();
			}
			zos.closeEntry();
			zos.close();
			// test the created zip
			// FileOutputStream fos = new FileOutputStream("c:\\all\\mytext.zip");
			// fos.write(baos.toByteArray());
			// fos.close();
			zipFile = baos.toByteArray();

			// return zipFile;
			/*
			 * InputStream isZipFile = new ByteArrayInputStream(zipFile);
			 * 
			 * 
			 * ///////////////////////////////////// resource = new InputStreamResource(is);
			 * System.out.println("filename====================>" + resource.getFilename());
			 * headers = new HttpHeaders(); headers.add("Cache-Control",
			 * "no-cache, no-store, must-revalidate"); headers.add("Pragma", "no-cache");
			 * headers.add("Expires", "0"); headers.add("Content-Disposition",
			 * "attachment; filename=" + newDocument.getContentStreamFileName());
			 */
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				baos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block

				e.printStackTrace();
			}

			finally {
				if (session != null) {
					session.clear();
				}
			}
		}
		logger.debug("exited method " + "bulkDownload");
		return zipFile;
	}

	public List<String> getAllDocumentVersion(String documentId) {
		final String methodName = "createContent";
		logger.debug("Entered into method :: " + methodName);
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		// logger.debug("User pass :: "+arr[0]+":"+arr[1]);

		List<String> versionList = new ArrayList<String>();
		try {
			Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0],
					arr[1]);
			if (curSession == null)
				throw new Exception("Unauthorized access");
			Document doc = (Document) curSession.getObject(documentId);

			for (Document version : doc.getAllVersions()) {
				// System.out.println(version.getVersionLabel());
				versionList.add(version.getVersionLabel());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.debug("Exited from method :: " + methodName);
		return versionList;
	}

	private Session getSession(String connectionName, String username, String pwd) {
		ConcurrentHashMap<String, Session> connections = new ConcurrentHashMap<String, Session>();
		Session session = connections.get(connectionName);
		if (session == null) {
			System.out.println(
					"Not connected, creating new connection to DMS with the connection id (" + connectionName + ")");

			// No connection to Alfresco available, create a new one
			SessionFactory sessionFactory = SessionFactoryImpl.newInstance();
			HashMap<String, String> parameters = new HashMap<String, String>();
			parameters.put(SessionParameter.USER, alfrescoUser);
			parameters.put(SessionParameter.PASSWORD, alfrescoPassword);
			parameters.put(SessionParameter.ATOMPUB_URL,
					alfrescoUrl + "/alfresco/api/-default-/cmis/versions/1.1/atom");
			parameters.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value());
			parameters.put(SessionParameter.COMPRESSION, "true");
			parameters.put(SessionParameter.CACHE_TTL_OBJECTS, "0"); // Caching is turned off

			// If there is only one repository exposed (e.g. Alfresco), these
			// lines will help detect it and its ID
			List<Repository> repositories = sessionFactory.getRepositories(parameters);
			Repository alfrescoRepository = null;
			if (repositories != null && repositories.size() > 0) {
				System.out.println("Found (" + repositories.size() + ") DMS repositories");
				alfrescoRepository = repositories.get(0);
				/*
				 * System.out.println("Info about the first Alfresco repo [ID=" +
				 * alfrescoRepository.getId() + "][name=" + alfrescoRepository.getName() +
				 * "][CMIS ver supported=" + alfrescoRepository.getCmisVersionSupported() +
				 * "]");
				 */
			} else {
				throw new CmisConnectionException("Could not connect to the DMS Server, no repository found!");
			}

			// Create a new session with the Alfresco repository
			session = alfrescoRepository.createSession();

			// Save connection for reuse
			connections.put(connectionName, session);
		} else {
			System.out.println("Already connected to Alfresco with the connection id (" + connectionName + ")");
		}

		return session;
	}

	private HttpHeaders createHttpHeaders(String user, String password) {
		String notEncoded = user + ":" + password;
		String encodedAuth = "Basic " + Base64.getEncoder().encodeToString(notEncoded.getBytes());
		// System.out.println("encodedauth =>"+encodedAuth);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Authorization", encodedAuth);
		return headers;
	}

	public byte[] versionedDocumentDownload(DocumentIdRequest id) {
		logger.info("Entered method " + "versionedDocumentDownload");
		String docid = id.getDocumentId();
		ServiceResponseStatics errorResponse = new ServiceResponseStatics();
		String theUrl = "";
		if (docid.contains(";")) {
			String[] arr = docid.split(";");
			String nodeid = arr[0];
			String versionLabel = arr[1];
			theUrl = alfrescoUrl + "/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeid + "/versions/"
					+ versionLabel + "/content";
		} else {
			String nodeid = docid;
			theUrl = alfrescoUrl + "/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeid + "/content";
		}

		Resource resource = null;
		HttpHeaders headers1 = null;
		ResponseEntity<Resource> res = null;
		// b5778a2d-911e-41af-a744-1aef92fc12ad
		byte[] file = null;
//	    RestTemplate restTemplate = new RestTemplate();
		try {
			HttpHeaders headers = createHttpHeaders(alfrescoUser, alfrescoPassword);
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			ResponseEntity<byte[]> response = restTemplate.exchange(theUrl, HttpMethod.GET, entity, byte[].class);
			// System.out.println("Result - status ("+ response.getStatusCode() + ") has
			// body: " + response.hasBody());
			// Files.write(Paths.get("c:\\all\\newfile.txt"), response.getBody());
			// final Document newDocument =
			// (Document)this.getSession("filedownloadConnection", alfrescoUser,
			// alfrescoPassword).getObject(docid);
			file = response.getBody();
			// InputStream is = new ByteArrayInputStream(response.getBody());
			// resource = new InputStreamResource(is);
			// headers1 = new HttpHeaders();
			// headers1.add("Cache-Control", "no-cache, no-store, must-revalidate");
			// headers1.add("Pragma", "no-cache");
			// headers1.add("Expires", "0");
			// headers1.add("Content-Disposition", "attachment; filename=" +
			// newDocument.getContentStreamFileName());
		}

		catch (Exception ex) {

			errorResponse.setMessage("can not fetch the object from repository");
			errorResponse.setStatus("1");
			Gson json = new Gson();
			String error = json.toJson(errorResponse);
			return error.getBytes();

		}

		/*
		 * res= ResponseEntity.ok() .headers(headers1)
		 * .contentLength(resource.contentLength())
		 * .contentType(MediaType.APPLICATION_OCTET_STREAM) .body(resource);
		 */

		logger.info("Exited method " + "versionedDocumentDownload");
		return file;

	}
	

	private String sanitizeHTML(String untrustedHTML) {
		PolicyFactory policy = new HtmlPolicyBuilder().allowAttributes("src").onElements("img").allowAttributes("href")
				.onElements("a").allowStandardUrlProtocols().allowElements("a", "img").toFactory();

		return policy.sanitize(untrustedHTML);

	}

	public Folder createFolder(Session cmisSession, Folder parentFolder, String folderName) {

		Folder subFolder = null;
		try {
			// Making an assumption here that you probably wouldn't normally do
			subFolder = (Folder) cmisSession.getObjectByPath(parentFolder.getPath() + "/" + folderName);
			System.out.println("Folder already existed!");
		} catch (CmisObjectNotFoundException onfe) {
			Map<String, Object> props = new HashMap<String, Object>();
			props.put("cmis:objectTypeId", "cmis:folder");
			props.put("cmis:name", folderName);
			subFolder = parentFolder.createFolder(props);
			String subFolderId = subFolder.getId();
			System.out.println("Created new folder: " + subFolderId);
		}

		return subFolder;
	}

	public void m(Session session) {

		Folder subFolder = null;

		Folder parentFolder = session.getRootFolder();
		try {
			subFolder = (Folder) session.getObjectByPath(parentFolder.getPath() + "folderName");
			System.out.println("Folder already existed!");
		} catch (CmisObjectNotFoundException onfe) {
			Map props = new HashMap();
			props.put("cmis:objectTypeId", "cmis:folder");
			props.put("cmis:name", "folderName");
			subFolder = parentFolder.createFolder(props);
			String subFolderId = subFolder.getId();
			System.out.println("Created new folder: " + subFolderId);
		}
	}

	public String createContentSites(RmsUploadRequest req, MultipartFile file) throws Exception {
		logger.debug("Entered into method ::: createContentSites");
		String arr[] = DMSUtility.INSTANCE.getUserPass(DMSUtility.INSTANCE.getHeader());
		// logger.debug("User pass :: "+arr[0]+":"+arr[1]);
		String url = DMSUtility.INSTANCE.getAlfBaseUrlLocal();
		// logger.debug("=======>"+url);
		Session curSession = DMSUtility.INSTANCE.getSession(DMSUtility.INSTANCE.getAlfBaseUrlLocal(), arr[0], arr[1]);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate now = LocalDate.now();
		String dateFolderName = dtf.format(now);
		Folder parentSubfolder = getParentNode(dateFolderName, curSession);

		System.out.println(">>>>>>>" + parentSubfolder.getId());
		System.out.println(">>>>>>>" + parentSubfolder.getName());

		Document doc = null;

		int extId = file.getOriginalFilename().lastIndexOf(".");
		String ext = file.getOriginalFilename().substring(extId);
		String title = req.getTitle();
		req.setTitle(title + "-" + String.valueOf(System.currentTimeMillis()));
		String completeFileName = req.getTitle() + ext;
		Map<String, Object> properties = getContentProperties(req, ext);
//	int i = 0;
		System.out.println("completeFileName:.." + completeFileName);

		ContentStream cs = curSession.getObjectFactory().createContentStream(completeFileName, file.getSize(),
				file.getContentType(), file.getInputStream());

		System.out.println("Content:::" + cs);

		try {
			doc = parentSubfolder.createDocument(properties, cs, VersioningState.MINOR);
			System.out.println("DOC ID: " + doc.getId());
		} catch (CmisContentAlreadyExistsException e) {
			SimpleDateFormat ss = new SimpleDateFormat("mmss");
			req.setTitle(req.getTitle() + "-" + ss.format(new Date()));
			properties.put(PropertyIds.NAME, req.getTitle() + ext);
			doc = parentSubfolder.createDocument(properties, cs, VersioningState.MINOR);
		} finally {
			// Close session and release resources
			try {
				curSession.clear();
			} catch (CmisContentAlreadyExistsException e) {
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String stackTrace = sw.toString();
				logger.error("Exception - " + stackTrace);
			}
		}

//	if (doc != null)
//		// saveMetadata(doc.getId(), req, doc.getName(), req.getRegion().get(i), null,
//		// req.getUserGroup(), path);
//		i++;
//	// }

		logger.debug("Exited from method ::: createContentSites");
//	curSession.clear();
		return doc.getId();
	}

	public ByteArrayInputStream downloadDocument(DocumentDownloadRequestNew documentDownloadRequest) {
		logger.info("Start Method " + "downloadDocument");
		ServiceResponseStatics serviceResponse = new ServiceResponseStatics();
		DocumentIdRequest req = new DocumentIdRequest();
		byte[] zipFile = null;
		try {
			req.setDocumentId(documentDownloadRequest.getDocumentId());
			zipFile = versionedDocumentDownload(req);
		} catch (Exception e) {
			serviceResponse.setStatus("2");
			serviceResponse.setMessage("Error");
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String stackTrace = sw.toString();
			logger.error("Exception - " + stackTrace);
		}
		logger.info("Exit Method " + "downloadDocument");
		return new ByteArrayInputStream(zipFile);

	}
	
	public String downloadDocumentBase64(DocumentIdRequest id) {
		logger.info("Start Method " + "downloadDocumentBase64");
		byte[] zipFile = null;
		try {
			zipFile = versionedDocumentDownload(id);
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String stackTrace = sw.toString();
			logger.error("Exception - " + stackTrace);
		}
		logger.info("Exit Method " + "downloadDocumentBase64");
		return Base64.getEncoder().encodeToString(zipFile);

	}

}
