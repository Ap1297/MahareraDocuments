package com.pwc.dms.enums;



public enum APP_MODE {
	OFFLINE,
	ONLINE
}
