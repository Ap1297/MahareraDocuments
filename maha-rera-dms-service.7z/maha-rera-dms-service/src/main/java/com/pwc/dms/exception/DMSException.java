package com.pwc.dms.exception;



public class DMSException extends Exception{
	private static final long serialVersionUID = 1L;
	public DMSException() {
		super();
	}
	public DMSException(String msg) {
		super(msg);
	}
}
