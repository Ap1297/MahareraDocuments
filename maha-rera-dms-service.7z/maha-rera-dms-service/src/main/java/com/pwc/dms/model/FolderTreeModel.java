package com.pwc.dms.model;

import java.util.List;

public class FolderTreeModel {
	private String label;
	private String key;
	private String expandedIcon;
	private String collapsedIcon;
	private List<FolderTreeModel> children;
	private boolean leaf;
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getLabel() {
		return label;
	}
	
	public List<FolderTreeModel> getChildren() {
		return children;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
	public void setChildren(List<FolderTreeModel> children) {
		this.children = children;
	}

	public String getExpandedIcon() {
		return "fa fa-folder-open";
	}

	public String getCollapsedIcon() {
		return "fa fa-folder";
	}
	
	public boolean isLeaf() {
		return false;
	}

}
