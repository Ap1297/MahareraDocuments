package com.pwc.dms.constants;



public class Constants {
	public static final String UNKNOWN_ERROR_MSG="An error occured";
	public static final String PATH_TO_NODE = "/alfresco/api/-default-/public/alfresco/versions/1/nodes/";
	public static final String CHILDREN = "/children";
	public static final String ROOT = "root";
	public static final String PROP_ALFRESCO_LOCAL_URL = "alfresco_local_base_url";
	public static final String FOLDER_PATH_SEPERATOR = "/";
	public static final String PROP_ALFRESCO_REMOTE_URL = "alfresco_remote_base_url";
	public static final String PROP_DMS_REMOTE_URL = "dms_remote_base_url";
	public static final String PROP_ALFRESCO_LOCAL_PASS = "alfresco_local_pass";
	public static final String PROP_ALFRESCO_REMOTE_PASS = "alfresco_remote_pass";
	

	
}
