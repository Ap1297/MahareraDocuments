package com.pwc.dms.model;


public class NodePoperties {
	private String title;
	private String taggable;
	private String description;
	public String getTitle() {
		return title;
	}
	public String getTaggable() {
		return taggable;
	}
	public String getDescription() {
		return description;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setTaggable(String taggable) {
		this.taggable = taggable;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
