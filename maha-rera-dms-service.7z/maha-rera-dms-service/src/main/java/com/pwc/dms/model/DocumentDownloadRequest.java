package com.pwc.dms.model;

import java.util.List;

public class DocumentDownloadRequest {
	
	List<String> docIds;

	public List<String> getDocIds() {
		return docIds;
	}

	public void setDocIds(List<String> docIds) {
		this.docIds = docIds;
	}

}
