package com.pwc.dms.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.apache.chemistry.opencmis.commons.exceptions.CmisConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.pwc.dms.model.DocumentDownloadRequest;
import com.pwc.dms.model.DocumentDownloadRequestNew;
import com.pwc.dms.model.DocumentIdRequest;
import com.pwc.dms.model.GetAllVersionsRequest;
import com.pwc.dms.model.NewFileUploadResponse;
import com.pwc.dms.model.RmsUploadRequest;
import com.pwc.dms.model.UpdateVersionResponse;
import com.pwc.dms.service.impl.NodeService;


@RestController
@RequestMapping("/batch-job")
public class BatchJobController {

	@Autowired
	NodeService nodeService;

	@Value("${alfresco_local_base_url}")
	String alfrescoUrl;

	@Value("${sharedDirectoryName}")
	String directoryName;

	@PostMapping(path = "/uploadFilesToAlfresco")
	public NewFileUploadResponse uploadMultipleFiles(@RequestParam("file") MultipartFile[] files) {
		RmsUploadRequest rms = new RmsUploadRequest();
		List<String> pathList = new ArrayList<String>();
		List<String> listDocId = new ArrayList<String>();
		NewFileUploadResponse response = new NewFileUploadResponse();
		for (MultipartFile file : files) {

			try {
				List<String> listPath = new ArrayList<String>();
				// change the direcory here
				// System.out.println("=="+directoryName+"==");
				listPath.add(directoryName);
				int index = file.getOriginalFilename().lastIndexOf(".");
				String ext = file.getOriginalFilename().substring(index);
				String fileNameWithOutExt = file.getOriginalFilename().replaceFirst("[.][^.]+$", "");
				rms.setTitle(fileNameWithOutExt);
				rms.setPath(listPath);
//				String docId = nodeService.createContent(rms,  file);
				String docId = nodeService.createContentSites(rms, file);
				listDocId.add(docId);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				response.setErrorMessage("FAILURE");
				e1.printStackTrace();
			}

			try {
				// file.transferTo(ordinaryFile);
				// HashMap<String,String> mapDocId = nodeService.createBulkContent(rms,
				// ordinaryFile);
				// for(String key: mapDocId.keySet()){
				// System.out.println("key at controller====>"+key);
				// }
				// System.out.println
				// ("==>"+documentService.downloadFileService(mapDocId.get(file.getOriginalFilename())));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		response.setFileUploadResponse(listDocId);
		response.setErrorMessage("SUCCESS");
		return response;
	}

	@PostMapping(path = "/updateVersion")
	public @ResponseBody UpdateVersionResponse updateVersion(@RequestParam("file") MultipartFile file,
			@RequestParam("docId") String docId) {
		RmsUploadRequest rms = new RmsUploadRequest();
		List<String> pathList = new ArrayList<String>();
		UpdateVersionResponse updateVersionResponse = new UpdateVersionResponse();

		return nodeService.createContentWithVersion(rms, file, docId);
	}

	@PostMapping(path = "/getAllVersions")
	public List<String> getAllVersions(@RequestBody GetAllVersionsRequest request) {

		return nodeService.getAllDocumentVersion(request.getDocumentId());
	}

	private File getMultipartFile(String pathStr) {
		File file = new File(pathStr);
		return file;
	}

	@RequestMapping(value = "/filedownlaodzip/", method = RequestMethod.POST, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public @ResponseBody byte[] downloadRmsObject1(@RequestBody DocumentDownloadRequest docRequest) {

		return nodeService.bulkDownload(docRequest);
	}

	private Session getSession(String connectionName, String username, String pwd) {
		ConcurrentHashMap<String, Session> connections = new ConcurrentHashMap<String, Session>();
		Session session = connections.get(connectionName);
		if (session == null) {
			System.out.println("Not connected, creating new connection to Alfresco with the connection id ("
					+ connectionName + ")");

			// No connection to Alfresco available, create a new one
			SessionFactory sessionFactory = SessionFactoryImpl.newInstance();
			HashMap<String, String> parameters = new HashMap<String, String>();
			parameters.put(SessionParameter.USER, username);
			parameters.put(SessionParameter.PASSWORD, pwd);
			parameters.put(SessionParameter.ATOMPUB_URL,
					alfrescoUrl + "/alfresco/api/-default-/cmis/versions/1.1/atom");
			parameters.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value());
			parameters.put(SessionParameter.COMPRESSION, "true");
			parameters.put(SessionParameter.CACHE_TTL_OBJECTS, "0"); // Caching is turned off

			// If there is only one repository exposed (e.g. Alfresco), these
			// lines will help detect it and its ID
			List<Repository> repositories = sessionFactory.getRepositories(parameters);
			Repository alfrescoRepository = null;
			if (repositories != null && repositories.size() > 0) {
				System.out.println("Found (" + repositories.size() + ") Alfresco repositories");
				alfrescoRepository = repositories.get(0);
				System.out.println("Info about the first Alfresco repo [ID=" + alfrescoRepository.getId() + "][name="
						+ alfrescoRepository.getName() + "][CMIS ver supported="
						+ alfrescoRepository.getCmisVersionSupported() + "]");
			} else {
				throw new CmisConnectionException("Could not connect to the Alfresco Server, no repository found!");
			}

			// Create a new session with the Alfresco repository
			session = alfrescoRepository.createSession();

			// Save connection for reuse
			connections.put(connectionName, session);
		} else {
			System.out.println("Already connected to Alfresco with the connection id (" + connectionName + ")");
		}

		return session;
	}

	/*
	 * @GetMapping("/fileDownlaod/{id}") public ResponseEntity<Resource>
	 * downloadRmsObject(@PathVariable final String id) { final String methodName =
	 * "downloadRmsObject"; final Document newDocument =
	 * (Document)this.getSession("filedownloadConnection", "", "").getObject(id);
	 * final InputStreamReader isr = null; HttpHeaders headers = null;
	 * InputStreamResource resource = null; try {
	 * System.out.println("ContentType===================>" +
	 * newDocument.getContentStreamMimeType());
	 * System.out.println("ContentLength===================>" +
	 * newDocument.getContentStreamLength());
	 * System.out.println(newDocument.getId());
	 * System.out.println(newDocument.getContentStreamFileName()); final
	 * ContentStream cs = newDocument.getContentStream((String)null); final
	 * InputStream is = cs.getStream(); resource = new InputStreamResource(is);
	 * //byte[] initialArray = { 0, 1, 2 }; //InputStream targetStream = new
	 * ByteArrayInputStream(initialArray); //resource = new
	 * InputStreamResource(targetStream);
	 * System.out.println("filename====================>" + resource.getFilename());
	 * headers = new HttpHeaders(); headers.add("Cache-Control",
	 * "no-cache, no-store, must-revalidate"); headers.add("Pragma", "no-cache");
	 * headers.add("Expires", "0"); headers.add("Content-Disposition",
	 * "attachment; filename=" + newDocument.getContentStreamFileName());
	 * //headers.add("Content-Disposition", "attachment; filename=" +
	 * "attachement.zip"); } catch (Exception ex) { ex.printStackTrace(); } return
	 * ResponseEntity.ok() .headers(headers)
	 * .contentLength(newDocument.getContentStreamLength())
	 * .contentType(MediaType.APPLICATION_OCTET_STREAM) .body(resource); }
	 */

	public byte[] makeZipFile(ArrayList<String> srcFiles, String warFileName) throws Exception {
		// List<String> srcFiles = Arrays.asList("test1.txt", "test2.txt");
		FileOutputStream fos = new FileOutputStream(warFileName);
		ZipOutputStream zipOut = new ZipOutputStream(fos);
		for (String srcFile : srcFiles) {
			File fileToZip = new File(srcFile);
			FileInputStream fis = new FileInputStream(fileToZip);
			ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
			zipOut.putNextEntry(zipEntry);

			byte[] bytes = new byte[1024];
			int length;
			while ((length = fis.read(bytes)) >= 0) {
				zipOut.write(bytes, 0, length);
			}
			fis.close();
		}
		zipOut.close();
		fos.close();
		return null;
	}

	@PostMapping("/versionedDocumentDownload")
	public @ResponseBody byte[] versionedDocumentDownload(@RequestBody DocumentIdRequest id) {
		return nodeService.versionedDocumentDownload(id);
	}
	
	@PostMapping(path = "/downloadDocument")
	public ResponseEntity<InputStreamResource> downloadDocument(@RequestBody DocumentDownloadRequestNew documentDownloadRequest)
			throws Exception {
		
		ByteArrayInputStream bis = nodeService
				.downloadDocument(documentDownloadRequest);

		HttpHeaders headers = new HttpHeaders();
		int index= documentDownloadRequest.getFileName().lastIndexOf('.');
		String extension = documentDownloadRequest.getFileName().substring(index+1);
		switch(extension) {
		case "pdf" :
			headers.add("Content-Disposition", "inline; filename=" +documentDownloadRequest.getFileName());
			headers.setContentType(MediaType.APPLICATION_PDF);
			break;
			
		case "jpeg" :
			
			headers.add("Content-Disposition", "inline; filename="
					+documentDownloadRequest.getFileName());
			headers.setContentType(MediaType.IMAGE_JPEG);
			
         case "jpg" :
			
			headers.add("Content-Disposition", "inline; filename="
					+documentDownloadRequest.getFileName());
			headers.setContentType(MediaType.IMAGE_JPEG);
			
         case "png" :
 			
 			headers.add("Content-Disposition", "inline; filename="
 					+documentDownloadRequest.getFileName());
 			headers.setContentType(MediaType.IMAGE_PNG);
 			
 			break;
 			
         case "xlsx" :
  			
  			headers.add("Content-Disposition", "inline; filename="
  					+documentDownloadRequest.getFileName());
  			headers.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
  			
  			break;
 			
			
		}
		
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(bis));
		
		
	}
	
	
	@PostMapping(path = "/downloadDocumentV2")
	public ResponseEntity<InputStreamResource> downloadDocumentV2(@RequestBody DocumentDownloadRequestNew documentDownloadRequest)
			throws Exception {
		
		ByteArrayInputStream bis = nodeService
				.downloadDocument(documentDownloadRequest);

		HttpHeaders headers = new HttpHeaders();
		int index= documentDownloadRequest.getFileName().lastIndexOf('.');
		String extension = documentDownloadRequest.getFileName().substring(index+1);
		switch(extension) {
		case "pdf" :
			headers.add("Content-Disposition", "inline; filename=" +documentDownloadRequest.getFileName());
			headers.setContentType(MediaType.APPLICATION_PDF);
			break;
			
		case "jpeg" :
			
			headers.add("Content-Disposition", "inline; filename="
					+documentDownloadRequest.getFileName());
			headers.setContentType(MediaType.IMAGE_JPEG);
			
         case "jpg" :
			
			headers.add("Content-Disposition", "inline; filename="
					+documentDownloadRequest.getFileName());
			headers.setContentType(MediaType.IMAGE_JPEG);
			
         case "png" :
 			
 			headers.add("Content-Disposition", "inline; filename="
 					+documentDownloadRequest.getFileName());
 			headers.setContentType(MediaType.IMAGE_PNG);
 			
 			break;
 			
         case "xlsx" :
  			
  			headers.add("Content-Disposition", "inline; filename="
  					+documentDownloadRequest.getFileName());
  			headers.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
  			
  			break;
 			
			
		}
		
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(bis));
		
		
	}
	
	@PostMapping("/downloadDocumentBase64")
	public String downloadDocumentBase64(@RequestBody DocumentIdRequest id) {
		return nodeService.downloadDocumentBase64(id);
	}


}
