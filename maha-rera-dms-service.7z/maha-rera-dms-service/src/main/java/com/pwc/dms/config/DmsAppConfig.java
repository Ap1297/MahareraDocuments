package com.pwc.dms.config;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.pwc.dms.utils.DMSUtility;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import com.pwc.dms.constants.Constants;

/*import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
*/


@Configuration
//@EnableSwagger2
//@Profile({"swagger"})
public class DmsAppConfig{
	@Autowired
	private Environment env;
	
	/*@Bean
    public Docket productApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select().apis(RequestHandlerSelectors.basePackage("com.pwc.dms.controller"))
                .build();
    }*/
	
	/*
	 * @Bean public WebMvcConfigurer corsConfigurer() { return new
	 * WebMvcConfigurer() {
	 * 
	 * @Override public void addCorsMappings(CorsRegistry registry) {
	 * registry.addMapping("/**").allowedOrigins("*"); } }; }
	 */
	
	@Bean
	DMSUtility initUtilBean() {
		DMSUtility.INSTANCE.setAlfBaseUrlLocal(env.getProperty(Constants.PROP_ALFRESCO_LOCAL_URL));
		DMSUtility.INSTANCE.setAlfBaseUrlRemote(env.getProperty(Constants.PROP_ALFRESCO_REMOTE_URL));
		DMSUtility.INSTANCE.setRemoteDmsUrl(env.getProperty(Constants.PROP_DMS_REMOTE_URL));
		DMSUtility.INSTANCE.setAlfPass(env.getProperty(Constants.PROP_ALFRESCO_LOCAL_PASS));
		DMSUtility.INSTANCE.setRemotePass(env.getProperty(Constants.PROP_ALFRESCO_REMOTE_PASS));
		
		
		return DMSUtility.INSTANCE;
	}
	
	
	
	
}
